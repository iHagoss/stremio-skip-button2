package com.tvplayer.app.skip

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class SkipRangeManager {
    
    private val client = OkHttpClient()
    private val gson = Gson()
    private val mainHandler = Handler(Looper.getMainLooper())
    
    companion object {
        private const val TAG = "SkipRangeManager"
        private const val BASE_URL = "https://busy-jacinta-shugi-c2885b2e.koyeb.app"
    }
    
    data class SkipRange(
        @SerializedName("start")
        val start: Double,
        
        @SerializedName("end")
        val end: Double,
        
        @SerializedName("type")
        val type: String
    )
    
    data class SkipRangesResponse(
        @SerializedName("ranges")
        val ranges: List<SkipRange>?
    )
    
    interface SkipRangesCallback {
        fun onSuccess(ranges: List<SkipRange>)
        fun onError(error: Exception)
    }
    
    fun fetchSkipRanges(episodeId: String, fileHash: String, callback: SkipRangesCallback) {
        val url = "$BASE_URL/ranges/$episodeId?fileId=$fileHash"
        
        Log.d(TAG, "Fetching skip ranges from: $url")
        
        val request = Request.Builder()
            .url(url)
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to fetch skip ranges", e)
                mainHandler.post {
                    callback.onError(e)
                }
            }
            
            override fun onResponse(call: Call, response: Response) {
                try {
                    if (!response.isSuccessful) {
                        throw IOException("Unexpected response code: ${response.code}")
                    }
                    
                    val responseBody = response.body?.string()
                    if (responseBody.isNullOrEmpty()) {
                        throw IOException("Empty response body")
                    }
                    
                    Log.d(TAG, "Received response: $responseBody")
                    
                    val rangesResponse = gson.fromJson(responseBody, SkipRangesResponse::class.java)
                    val ranges = rangesResponse.ranges ?: emptyList()
                    
                    Log.d(TAG, "Parsed ${ranges.size} skip ranges")
                    
                    mainHandler.post {
                        callback.onSuccess(ranges)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing skip ranges", e)
                    mainHandler.post {
                        callback.onError(e)
                    }
                }
            }
        })
    }
    
    fun getRangeLabel(type: String): String {
        return when (type.lowercase()) {
            "cold_open" -> "Skip Cold Open"
            "credits" -> "Skip Credits"
            "credits_end" -> "Skip End Credits"
            "intro" -> "Skip Intro"
            "recap" -> "Skip Recap"
            "preview" -> "Skip Preview"
            else -> "Skip"
        }
    }
    
    fun isInRange(currentPositionSeconds: Double, range: SkipRange): Boolean {
        return currentPositionSeconds >= range.start && currentPositionSeconds < range.end
    }
    
    fun findActiveRange(currentPositionSeconds: Double, ranges: List<SkipRange>): SkipRange? {
        return ranges.firstOrNull { range ->
            isInRange(currentPositionSeconds, range)
        }
    }
}
