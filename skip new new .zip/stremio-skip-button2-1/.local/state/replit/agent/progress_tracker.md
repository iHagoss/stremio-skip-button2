[x] 1. Install the required packages (Java already installed)
[x] 2. Configure workflow to display project information
[x] 3. Verify the workflow is working properly
[x] 4. Inform user the import is completed and they can start building, mark the import as completed using the complete_project_import tool