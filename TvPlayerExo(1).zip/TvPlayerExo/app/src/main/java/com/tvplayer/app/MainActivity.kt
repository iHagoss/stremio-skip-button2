package com.tvplayer.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.StyledPlayerView
import com.tvplayer.app.skip.SkipOverlay
import com.tvplayer.app.skip.SkipRangeManager

class MainActivity : AppCompatActivity() {

    private lateinit var playerView: StyledPlayerView
    private var player: ExoPlayer? = null
    private lateinit var skipOverlayContainer: FrameLayout
    
    private lateinit var skipRangeManager: SkipRangeManager
    private var skipOverlay: SkipOverlay? = null
    
    private val updateHandler = Handler(Looper.getMainLooper())
    private var updateRunnable: Runnable? = null
    
    companion object {
        private const val TAG = "MainActivity"
        private const val VIDEO_URL = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
        private const val UPDATE_INTERVAL_MS = 500L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        playerView = findViewById(R.id.player_view)
        skipOverlayContainer = findViewById(R.id.skipOverlayContainer)
        
        skipRangeManager = SkipRangeManager()
        
        initializePlayer()
        setupSkipOverlay()
    }

    private fun initializePlayer() {
        val videoUrl = getVideoUrlFromIntent() ?: return
        
        player = ExoPlayer.Builder(this).build().apply {
            playerView.player = this
            
            val mediaItem = MediaItem.fromUri(Uri.parse(videoUrl))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
            
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_READY -> {
                            Log.d(TAG, "Player ready, starting position updates")
                            startPositionUpdates()
                            fetchSkipRanges()
                        }
                        Player.STATE_ENDED -> {
                            Log.d(TAG, "Playback ended")
                            stopPositionUpdates()
                        }
                    }
                }
            })
        }
    }

    private fun getVideoUrlFromIntent(): String? {
        val isExternalLaunch = Intent.ACTION_VIEW == intent.action
        
        val intentData = intent.data
        if (isValidVideoUri(intentData)) {
            Log.d(TAG, "Using video URL from intent data: $intentData")
            return intentData.toString()
        }
        
        val extraStream = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        if (isValidVideoUri(extraStream)) {
            Log.d(TAG, "Using video URL from extra stream: $extraStream")
            return extraStream.toString()
        }
        
        if (isExternalLaunch) {
            Toast.makeText(this, "No valid video URL provided", Toast.LENGTH_LONG).show()
            finish()
            return null
        }
        
        Log.d(TAG, "Using default video URL: $VIDEO_URL")
        return VIDEO_URL
    }

    private fun isValidVideoUri(uri: Uri?): Boolean {
        if (uri == null) return false
        
        val uriString = uri.toString()
        if (uriString.isNullOrEmpty()) return false
        
        val scheme = uri.scheme ?: return false
        
        return scheme == "http" || scheme == "https"
    }

    private fun setupSkipOverlay() {
        skipOverlay = SkipOverlay(this, skipOverlayContainer, skipRangeManager).apply {
            setOnSeekListener { seekPositionMs ->
                player?.seekTo(seekPositionMs)
                Log.d(TAG, "Seeking to position: ${seekPositionMs}ms")
            }
            
            setOnNextEpisodeListener {
                handleNextEpisode()
            }
        }
    }

    private fun fetchSkipRanges() {
        val episodeId = "demo-episode-1"
        val fileHash = "sample-hash-12345"
        
        Log.d(TAG, "Fetching skip ranges for episodeId: $episodeId, fileHash: $fileHash")
        
        skipRangeManager.fetchSkipRanges(episodeId, fileHash, object : SkipRangeManager.SkipRangesCallback {
            override fun onSuccess(ranges: List<SkipRangeManager.SkipRange>) {
                Log.d(TAG, "Successfully fetched ${ranges.size} skip ranges")
                skipOverlay?.setRanges(ranges)
            }
            
            override fun onError(error: Exception) {
                Log.e(TAG, "Failed to fetch skip ranges, using defaults", error)
                useDefaultRanges()
            }
        })
    }

    private fun useDefaultRanges() {
        val defaultRanges = listOf(
            SkipRangeManager.SkipRange(start = 0.0, end = 10.0, type = "cold_open"),
            SkipRangeManager.SkipRange(start = 540.0, end = 596.0, type = "credits_end")
        )
        Log.d(TAG, "Using ${defaultRanges.size} default skip ranges")
        skipOverlay?.setRanges(defaultRanges)
    }

    private fun startPositionUpdates() {
        stopPositionUpdates()
        
        updateRunnable = object : Runnable {
            override fun run() {
                player?.let { player ->
                    val currentPosition = player.currentPosition
                    skipOverlay?.updatePosition(currentPosition)
                }
                updateHandler.postDelayed(this, UPDATE_INTERVAL_MS)
            }
        }
        
        updateHandler.post(updateRunnable!!)
        Log.d(TAG, "Position updates started")
    }

    private fun stopPositionUpdates() {
        updateRunnable?.let {
            updateHandler.removeCallbacks(it)
        }
        updateRunnable = null
        Log.d(TAG, "Position updates stopped")
    }

    private fun handleNextEpisode() {
        Toast.makeText(
            this,
            "Next Episode - This will be wired to Syncler/Stremio metadata",
            Toast.LENGTH_LONG
        ).show()
        
        Log.d(TAG, "Next episode triggered - awaiting metadata integration")
    }

    override fun onStart() {
        super.onStart()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPositionUpdates()
        skipOverlay?.cleanup()
        player?.release()
        player = null
        Log.d(TAG, "Activity destroyed, resources released")
    }
}
