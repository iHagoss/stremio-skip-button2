# Stremio Skip Patcher Monorepo

This repository contains:
- patcher/: Android Studio project for the patcher app
- api/: Node.js skip metadata server
- analyzer/: Python analyzer to generate skip metadata
- temp./github/workflows/: CI workflows

Build instructions are included in each subfolder README.
