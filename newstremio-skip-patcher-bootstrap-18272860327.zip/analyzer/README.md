Analyzer CLI to generate skip JSON for Stremio Skip API.
Usage:
  python analyze.py --input /path/to/video --output out.json
